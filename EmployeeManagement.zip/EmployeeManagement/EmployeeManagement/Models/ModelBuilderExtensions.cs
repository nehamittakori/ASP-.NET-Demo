﻿using Microsoft.EntityFrameworkCore;

namespace EmployeeManagement.Models
{
    public static class ModelBuilderExtensions
    {
        public static void Seed(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>().HasData(
                new Employee
                {
                    Id = 1,
                    Name = "Jimin",
                    Department = Dept.IT,
                    Email = "jimin@gmail.com",
                    PhotoPath = "~/images/noimage.jpg"


                },
                 new Employee
                 {
                     Id = 2,
                     Name = "Tae",
                     Department = Dept.HR,
                     Email = "tae@gmail.com",
                     PhotoPath="~/images/tae.jpg"
                     
                 }
                );
        }
    }
}
