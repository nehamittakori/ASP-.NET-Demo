﻿namespace EmployeeManagement.Models
{
    public enum Dept
    {
        None,
        HR,
        IT,
        Payroll
    }
}
